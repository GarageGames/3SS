Search engine files:

 search.html - search query page, you can edit this file to customize the search box, or you can copy search box scripts to other html file;
 searchresult.html - search result page, you can edit this file to customize the search result page;
 searchfunc.js - search function scripts, do not modify it;
 searchdb.js - search engine database file, do not modify it;
 searchindex.js - search engine keyword database file, do not modify it.
 
To add site search to your online web site, do the following:

1. Upload search engine files to the web server, using any FTP client (e.g., CuteFTP).
2. run search.html to access the search query page. You can also copy the form in this file to other web page to access the search box.

To make an offline search engine, do the following:

1. Copy search engine files to the appropriate directory.
2. run search.html to access the search query page. You can also copy the form in this file to other web page to access the search box.
